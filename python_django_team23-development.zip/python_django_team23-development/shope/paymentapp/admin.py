from django.contrib import admin
from paymentapp.models import Card, Payment

admin.site.register(Card)
admin.site.register(Payment)
