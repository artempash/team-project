﻿from django.contrib import admin

from productsapp.models import ProductImage

admin.site.register(ProductImage)
