from django.contrib import admin
from productsapp.models.type_spec import TypeSpecific

admin.site.register(TypeSpecific)
