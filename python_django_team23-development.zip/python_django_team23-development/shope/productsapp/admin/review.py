from django.contrib import admin
from productsapp.models.review import Review

admin.site.register(Review)
