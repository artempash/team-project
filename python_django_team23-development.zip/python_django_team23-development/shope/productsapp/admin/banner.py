from django.contrib import admin
from productsapp.models import Banner

admin.site.register(Banner)
