from django.contrib import admin
from productsapp.models.specific import Specific

admin.site.register(Specific)
