from django.contrib import admin
from productsapp.models.category import Category

admin.site.register(Category)
