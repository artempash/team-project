from django.contrib import admin
from productsapp.models import Slider

admin.site.register(Slider)
