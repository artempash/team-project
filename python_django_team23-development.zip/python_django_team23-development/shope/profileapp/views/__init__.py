# flake8: noqa
from .profile_detail_view import ProfileDetailView
from .profile_update_view import ProfileUpdateView
from .viewed_products_view import ViewedProductsListView
