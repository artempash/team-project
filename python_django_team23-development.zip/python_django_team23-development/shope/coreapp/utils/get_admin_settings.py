class GetAdminSettings:
    """Получение административных настроек"""
    pass
