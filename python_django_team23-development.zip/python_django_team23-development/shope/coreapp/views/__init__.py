# flake8: noqa
from .index_view import IndexView
